import { sendSqsMessage } from './sqs'

export const handler = async (req: any) => {
    let body = req.body
    
    try {
      await sendSqsMessage(body)
      console.log('Message sent')
      return {
        statusCode: 200,
      }
    } catch (err) {
      const errorResponse = {
        statusCode: 500,
        body: {
          message: 'Error',
          data: JSON.stringify(err),
        },
      }
      console.error(errorResponse)
      return errorResponse
    }
  }