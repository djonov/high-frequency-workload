"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const sqs_1 = require("./sqs");
const handler = async (req) => {
    let body = req.body;
    try {
        await (0, sqs_1.sendSqsMessage)(body);
        console.log('Message sent');
        return {
            statusCode: 200,
        };
    }
    catch (err) {
        const errorResponse = {
            statusCode: 500,
            body: {
                message: 'Error',
                data: JSON.stringify(err),
            },
        };
        console.error(errorResponse);
        return errorResponse;
    }
};
exports.handler = handler;
//# sourceMappingURL=index.js.map