"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.server = exports.app = void 0;
const express_1 = __importDefault(require("express"));
const bodyParser = __importStar(require("body-parser"));
const typeorm_1 = require("typeorm");
exports.app = (0, express_1.default)();
let connection;
const runCalculation = async (area_plot) => {
    await setTimeout(() => { }, 100);
    return area_plot * 100;
};
const processRequest = async (req, res, next) => {
    try {
        console.log('Received new request to process');
        console.log(req.body.data);
        console.log(req.body.data.body);
        const { area_plot } = JSON.parse(req.body.data.body);
        const processedResult = await runCalculation(Number(area_plot));
        await connection.query(`INSERT INTO "processed" ("entryData", "predictedOutput") VALUES ($1, $2)`, [area_plot, processedResult]);
        return res.status(200).send({
            message: 'OK'
        });
    }
    catch (err) {
        console.log(err);
        return res.status(500).send();
    }
};
exports.app.use(bodyParser.json());
exports.app.post('/', processRequest);
const PORT = 8080;
const db = {
    type: 'postgres',
    host: process.env.DB_HOST,
    port: +process.env.DB_PORT, // convert to number with unary plus operator
    username: process.env.DB_USERNAME,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    ssl: { rejectUnauthorized: false }
};
(0, typeorm_1.createConnection)({
    ...db,
    migrationsRun: false
})
    .then(async (conn) => {
    connection = conn;
    console.log('Connected to DB');
    exports.server = exports.app.listen(PORT, () => {
        console.log('Server running on port ' + PORT);
    });
})
    .catch((error) => console.error(error));
//# sourceMappingURL=server.js.map